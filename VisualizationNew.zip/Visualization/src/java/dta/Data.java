package dta;

//import com.mysql.cj.result.Row;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Row;

public class Data implements Runnable {

    private int type;
    private String country;
    private String from;
    private String until;

    public Data(int type) {
        this.type = type;
    }

    public Data() {
        this.type = 1;
    }

    public Data(int type, String country) {
        this.type = type;
        this.country = country;
    }
    
    public Data(int type, String country, String from, String until) {
        this.type = type;
        this.country = country;
        this.from = from.replace("_","-");
        this.until = until.replace("_","-");
        System.out.println(this.from +" "+this.until);
    }

    public void dataWrite(String filename, String data) {
        try {
            FileWriter myObj = new FileWriter(filename);
            myObj.write(data);
            myObj.close();
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    public static String dataString(String filename) throws IOException {
        String content = null;
        File file = new File(filename);
        FileReader reader = null;
        try {
            reader = new FileReader(file);
            char[] chars = new char[(int) file.length()];
            reader.read(chars);
            content = new String(chars);
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                reader.close();
            }
        }
        return content.trim();
    }

    public String getDeathsByContinent() throws ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        try (
                
               
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/visualizedata", "root", "");  Statement stmt = conn.createStatement();) {

            String strSelect = "SELECT `dateRep` as dateRep,`continentExp` as category,sum(deaths) as value FROM `covid19` WHERE STR_TO_DATE(dateRep,'%d/%m/%Y') between STR_TO_DATE('"+this.from+"', '%Y-%m-%d') and STR_TO_DATE('"+this.until+"', '%Y-%m-%d') group by `dateRep`,`continentExp`  order by dateRep;";
            System.out.println(strSelect);
            String result = "";
            ResultSet rset = stmt.executeQuery(strSelect);

            ArrayList<String> europe = new ArrayList<>();
            ArrayList<String> asia = new ArrayList<>();
            ArrayList<String> oceania = new ArrayList<>();
            ArrayList<String> africa = new ArrayList<>();
            ArrayList<String> america = new ArrayList<>();

            int rowCount = 0;
            while (rset.next()) {   // Repeatedly process each row
                String _date = rset.getString("dateRep");  // retrieve a 'String'-cell in the row
                String _category = rset.getString("category");  // retrieve a 'double'-cell in the row
                int _value = rset.getInt("value");  // retrieve a 'double'-cell in the row

                if ("Africa".equals(_category)) {
                    africa.add("{x:" + africa.size() + ", y:" + _value + "}");
                } else if ("America".equals(_category)) {
                    america.add("{x:" + america.size() + ", y:" + _value + "}");
                } else if ("Oceania".equals(_category)) {
                    oceania.add("{x:" + oceania.size() + ", y:" + _value + "}");
                } else if ("Europe".equals(_category)) {
                    europe.add("{x:" + europe.size() + ", y:" + _value + "}");
                } else if ("Asia".equals(_category)) {
                    asia.add("{x:" + asia.size() + ", y:" + _value + "}");
                }

            }
            result += "europeData = [";
            for (int i = 0; i < europe.size(); i++) {
                result += europe.get(i) + ",\n";
            }
            result += "];\n";

            result += "asiaData = [";
            for (int i = 0; i < asia.size(); i++) {
                result += asia.get(i) + ",\n";
            }
            result += "];\n";

            result += "africaData = [";
            for (int i = 0; i < africa.size(); i++) {
                result += africa.get(i) + ",\n";
            }
            result += "];\n";

            result += "oceaniaData = [";
            for (int i = 0; i < oceania.size(); i++) {
                result += oceania.get(i) + ",\n";
            }
            result += "];\n";

            result += "americaData = [";
            for (int i = 0; i < america.size(); i++) {
                result += america.get(i) + ",\n";
            }
            result += "];\n";

            return result;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return null;
        }
    }
	
	private boolean isComment(String line) {
        if ((line != null) && (line.length() > 0)) {
            return (line.charAt(0) == '#');
        }
        return false;
    }

    private boolean checkStatementEnds(String s) {
        return (s.indexOf(";") != -1);
    }

    public void updateData(String filename) throws SQLException, FileNotFoundException, IOException, ClassNotFoundException {
        File script = new File(filename);
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/visualizedata", "root", "");
            con.setAutoCommit(false);
            PreparedStatement pstm = null;
            
            String dropTable = "drop table `covid19`";
            pstm = (PreparedStatement) con.prepareStatement(dropTable);
            pstm.execute();
            
            String createTable = "CREATE TABLE `covid19` (\n"
                    + "  `dateRep` varchar(10) DEFAULT NULL,\n"
                    + "  `day` int(11) DEFAULT NULL,\n"
                    + "  `month` int(11) DEFAULT NULL,\n"
                    + "  `year` int(11) DEFAULT NULL,\n"
                    + "  `cases` int(11) DEFAULT NULL,\n"
                    + "  `deaths` int(6) DEFAULT NULL,\n"
                    + "  `countriesAndTerritories` varchar(42) DEFAULT NULL,\n"
                    + "  `geoId` varchar(8) DEFAULT NULL,\n"
                    + "  `countryterritoryCode` varchar(20) DEFAULT NULL,\n"
                    + "  `popData2019` varchar(11) DEFAULT NULL,\n"
                    + "  `continentExp` varchar(12) DEFAULT NULL,\n"
                    + "  `Cumulative_number_for_14_days_of_COVID-19_cases_per_100000` varchar(58) DEFAULT NULL\n"
                    + ")";
            pstm = (PreparedStatement) con.prepareStatement(createTable);
            pstm.execute();
            con.setAutoCommit(true);
            FileInputStream input = new FileInputStream(filename);
            System.out.println(filename);
            try{
                POIFSFileSystem fs = new POIFSFileSystem(new File(filename));
                HSSFWorkbook wb = new HSSFWorkbook(fs);
            

            HSSFSheet sheet = wb.getSheetAt(0);
            Row row;
            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                try {
                    row = sheet.getRow(i);
                    
                    int day = (row.getCell(1)!=null?(int)row.getCell(1).getNumericCellValue():0);
                    int month = (row.getCell(2)!=null?(int) row.getCell(2).getNumericCellValue():0);
                    int year = (row.getCell(3)!=null?(int) row.getCell(3).getNumericCellValue():0);
                    String dateRep = day+"/"+month+"/"+year;
                    int cases = (row.getCell(4)!=null?(int) row.getCell(4).getNumericCellValue():0);
                    int deaths = (row.getCell(5)!=null?(int) row.getCell(5).getNumericCellValue():0);
                    String countriesAndTerritories = (row.getCell(6)!=null?row.getCell(6).getStringCellValue():"-");
                    String geoId = (row.getCell(7)!=null?row.getCell(7).getStringCellValue():"-");
                    String countryterritoryCode = (row.getCell(8)!=null?row.getCell(8).getStringCellValue():"-");
                    String popData2019 = (row.getCell(9)!=null?((int)row.getCell(9).getNumericCellValue())+"":"");
                    String continentExp = (row.getCell(10)!=null?row.getCell(10).getStringCellValue():"-");
                    String Cumulative_number_for_14_days_of_COVID_19_cases_per_100000 = "";
                
                    Cumulative_number_for_14_days_of_COVID_19_cases_per_100000 =  (row.getCell(11)!=null?((double)row.getCell(11).getNumericCellValue())+"":"0");
                

                String insertStatement = "INSERT INTO `covid19` (`dateRep`, `day`, `month`, `year`, `cases`, `deaths`, `countriesAndTerritories`, `geoId`, `countryterritoryCode`, `popData2019`, `continentExp`, `Cumulative_number_for_14_days_of_COVID-19_cases_per_100000`) VALUES (";
                insertStatement+="'"+dateRep+"',";
                insertStatement+="'"+day+"',";
                insertStatement+="'"+month+"',";
                insertStatement+="'"+year+"',";
                insertStatement+="'"+cases+"',";
                insertStatement+="'"+deaths+"',";
                insertStatement+="'"+countriesAndTerritories+"',";
                insertStatement+="'"+geoId+"',";
                insertStatement+="'"+countryterritoryCode+"',";
                insertStatement+="'"+popData2019+"',";
                insertStatement+="'"+continentExp+"',";
                insertStatement+="'"+Cumulative_number_for_14_days_of_COVID_19_cases_per_100000+"')";
                System.out.println(insertStatement);
                pstm = (PreparedStatement) con.prepareStatement(insertStatement);
                pstm.execute();
                }
                catch (Exception e){
                    e.printStackTrace();
                    continue;
                    //Cumulative_number_for_14_days_of_COVID_19_cases_per_100000 = "0";
                }
                
            }
            
            pstm.close();
            con.close();
            input.close();
            System.out.println("Success import excel to mysql table");
            }
            catch (Exception e){
                e.printStackTrace();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public static String getCovidData() throws ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        try (
                 Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/visualizedata", "root", "");  Statement stmt = conn.createStatement();) {

            String strSelect = "SELECT `dateRep` as date,`countriesAndTerritories` as name,`continentExp` as category,`deaths` as value FROM `covid19` WHERE 1 order by dateRep;";
            String result = "[";
            ResultSet rset = stmt.executeQuery(strSelect);

            int rowCount = 0;
            while (rset.next()) {   // Repeatedly process each row
                String _date = rset.getString("date");  // retrieve a 'String'-cell in the row
                String _name = rset.getString("name");  // retrieve a 'double'-cell in the row
                String _category = rset.getString("category");  // retrieve a 'double'-cell in the row
                int _value = rset.getInt("value");  // retrieve a 'double'-cell in the row
                result += "{";
                result += "\"date\":\"" + _date + "\",";
                result += "\"name\":\"" + _name + "\",";
                result += "\"category\":\"" + _category + "\",";
                result += "\"value\":\"" + _value + "\"";
                result += "},\n";
                ++rowCount;
                if (rowCount % 1000 == 0) {
                    System.out.println(rowCount);
                }
            }
            result += "]";

            return result;

        } catch (SQLException ex) {
            ex.printStackTrace();
            return null;
        }
    }

    public String getDeathsByMonthYearCountry() throws ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        try (
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/visualizedata", "root", "");  Statement stmt = conn.createStatement();) {

            String strSelect = "SELECT `month`,`year`,`countriesAndTerritories`,`deaths` FROM `covid19` where  `countriesAndTerritories`='" + this.country + "' group by `month`,`year` order by `month`,`year`";
            String result;
            String result1 = "[";
            String result2 = "[";
            ResultSet rset = stmt.executeQuery(strSelect);
            while (rset.next()) {   // Repeatedly process each row
                String month_year = "'"+rset.getInt("month") + "-" + rset.getInt("year")+"'";  // retrieve a 'String'-cell in the row
                int value = rset.getInt("deaths");  // retrieve a 'double'-cell in the row
                result1 += month_year + ",";
                result2 += value + ",";
            }
            result1 += "]";
            result2 += "]";
            result = "[" + result1 + "," + result2 + "]";
            return result;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    
    
    public String getEventsInCoutryByMonth() throws ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        try (
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/visualizedata", "root", "");  Statement stmt = conn.createStatement();) {

            String strSelect = "SELECT `month`,`year`,`countriesAndTerritories`,`cases` events FROM `covid19` where  `countriesAndTerritories`='" + this.country + "' group by `month`,`year` order by `year`,`month`";
            System.out.println(strSelect);
            String result1 = "[";
            String result2 = "[";
            
            ResultSet rset = stmt.executeQuery(strSelect);
            while (rset.next()) {   // Repeatedly process each row
                String month_year = "'"+rset.getInt("month") + "-" + rset.getInt("year")+"'";  // retrieve a 'String'-cell in the row
                int value = rset.getInt("events");  // retrieve a 'double'-cell in the row
                result1 += month_year + ",";
                result2 += value + ",";
            }
            result1 += "]";
            result2 += "]";
            String result = "[" + result1 + "," + result2 + "]";
            return result;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    public static String getCountries() throws ClassNotFoundException{
        Class.forName("com.mysql.cj.jdbc.Driver");
        try (
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/visualizedata", "root", "");  Statement stmt = conn.createStatement();) {

            String strSelect = "SELECT `countriesAndTerritories` as country FROM `covid19` group BY `countriesAndTerritories` ";
            System.out.println(strSelect);
            String result = "";
            
            ResultSet rset = stmt.executeQuery(strSelect);
            while (rset.next()) {   // Repeatedly process each row
                String country = rset.getString("country");  
                
                result += "<option value='"+country + "'>"+country+"</option>";
                
            }
            
            return result;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    public String getLocationData() throws ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        try (
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/visualizedata", "root", "");  Statement stmt = conn.createStatement();) {

            String strSelect = "SELECT `countryterritoryCode` as country, 100*avg(`deaths`/`cases`) as value FROM `covid19` group BY `countryterritoryCode` ";
            System.out.println(strSelect);
            String result1 = "[";
            String result2 = "[";
            
            ResultSet rset = stmt.executeQuery(strSelect);
            while (rset.next()) {   // Repeatedly process each row
                String country = rset.getString("country");  
                int value = rset.getInt("value");
                
                result1 += "'"+country + "',";
                result2 += ""+value + ",";
            }
            result1 += "]";
            result2 += "]";
            String result = "[" + result1 + "," + result2 + "]";
            return result;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    
    
    public String getDeathsByContinentsCountries() throws ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        try (
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/visualizedata", "root", "");  Statement stmt = conn.createStatement();) {

            String strSelect = "SELECT `countryterritoryCode`,sum(`deaths`) as deaths FROM `covid19` where  `continentExp`='" + this.country + "' group by `countryterritoryCode`";
            String result = "[";
            
            ResultSet rset = stmt.executeQuery(strSelect);
            while (rset.next()) {   // Repeatedly process each row
                String coun = rset.getString("countryterritoryCode");  // retrieve a 'String'-cell in the row
                int value = rset.getInt("deaths");  // retrieve a 'double'-cell in the row
                result += "{\"category\":\""+coun+"\", \"amount\":"+value+"},";
               
            }
            return result+"]";
        } catch (SQLException ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    public String getEventsByContinent() throws ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        
        try (
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/visualizedata", "root", "");  Statement stmt = conn.createStatement();) {

            String strSelect = "SELECT `continentExp` as category,avg(cases) as value FROM `covid19` WHERE 1 and STR_TO_DATE(dateRep,'%d/%m/%Y') between STR_TO_DATE('"+this.from+"', '%Y-%m-%d') and STR_TO_DATE('"+this.until+"', '%Y-%m-%d') group by category;";
            System.out.println(strSelect);
            String data = "[";
            
            ResultSet rset = stmt.executeQuery(strSelect);
            while (rset.next()) {   // Repeatedly process each row
                String coun = rset.getString("category");  // retrieve a 'String'-cell in the row
                int value = rset.getInt("value");  // retrieve a 'double'-cell in the row
                data += "{\"x\":\""+coun+"\", \"y\":"+value+"},";
               
            }
            return data+"]";
        } catch (SQLException ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    public String getDeathsByCountry() throws ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        
        try (
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/visualizedata", "root", "");  Statement stmt = conn.createStatement();) {

            String strSelect = "SELECT `countryterritoryCode`,avg(`Cumulative_number_for_14_days_of_COVID-19_cases_per_100000`) as deaths FROM `covid19` where 1 group by `countryterritoryCode` ";
            String result = "[";
            
            ResultSet rset = stmt.executeQuery(strSelect);
            while (rset.next()) {   // Repeatedly process each row
                String coun = rset.getString("countryterritoryCode");  // retrieve a 'String'-cell in the row
                int value = rset.getInt("deaths");  // retrieve a 'double'-cell in the row
                result += "{\"country\":\""+coun+"\", \"value\":"+value+"},";
               
            }
            return result+"]";
        } catch (SQLException ex) {
            ex.printStackTrace();
            return null;
        }
    }

    
    @Override
    public void run() {
        if (type == 1) {
            try {
                String res = getCovidData();
                dataWrite("dataDeathsPerCountry.csv", res);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Data.class.getName()).log(Level.SEVERE, null, ex);
            }

        } else if (type == 2) {
            //ΘΑΝΑΤΟΙ ΑΝΑ ΗΠΕΙΡΟ ΣΕ ΧΡΟΝΙΚΟ ΔΙΑΣΤΗΜΑ
            try {
                String res = getDeathsByContinent();
                dataWrite(from+until+"_DeathsPerContinent.csv", res);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Data.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else if (type == 3) {
            String res;
            try {
                res = getDeathsByMonthYearCountry();
                dataWrite(country + "DeathsPerMonth.csv", res);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Data.class.getName()).log(Level.SEVERE, null, ex);
            }

        } else if (type == 4) {
            String res;
            try {
                res = getDeathsByContinentsCountries();
                dataWrite(country + "DeathsPerContinentsCountries.csv", res);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Data.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
        else if (type == 5) {
            String res;
            try {
                res = getDeathsByCountry();
                dataWrite("DeathsPerCountryMap.csv", res);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Data.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
        else if (type == 6) {
            String res;
            try {
                res = getEventsInCoutryByMonth();
                dataWrite(country+"EventsPerCountry.csv", res);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Data.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
        else if (type == 7) {
            String res;
            try {
                res = getEventsByContinent();
                dataWrite(from+until+"_EventsPerContinent1.csv", res);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Data.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
        else if (type == 9) {
            String res;
            try {
                res = getEventsByContinent();
                dataWrite("EventsPerContinent1.csv", res);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Data.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
        
        else if (type == 10) {
            String res;
            try {
                res = getLocationData();
                dataWrite("LocationData.csv", res);
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Data.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
		else if (type == 100) {
            
            try {
                this.updateData(country);
                
            } catch (ClassNotFoundException | SQLException | IOException ex) {
                Logger.getLogger(Data.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
    }

}
